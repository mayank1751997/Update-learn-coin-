#ifndef QTIPCSERVER_H
#define QTIPCSERVER_H

// Define Bitcoin-Qt message queue name
#define BITCOINURI_QUEUE_NAME "BitcoinURI"

void ipcInit();

#endif // QTIPCSERVER_H
